export const URL_API_MN = "http://localhost:8000/api/v1/";
